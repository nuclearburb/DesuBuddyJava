#!/bin/bash
java -jar desubuddy.jar

